# EyesWorld-be

## Back-end of the EyesWorld app( Runs on TVOS)

* Framework: Spring + SpringMVC + MyBatis + Redis( Coming soon)
* The development process: [check the whole process](https://github.com/lianghao208/eyes-world-server/blob/master/README.md) 
* The development API(TV): [check the TV (PC) API document](https://github.com/lianghao208/EyesWorld-be/blob/master/api.md) 
* The development API(Mobile): [check the Mobile API document](https://github.com/lianghao208/eyes-world-api/blob/master/api-web.md) 
