package org.tvos.entity;

/**
 * Created by Administrator on 2017/7/26.
 */
public class College {
}
