package org.tvos.dto;

import org.tvos.entity.UserInfo;

/**
 * Created by Administrator on 2017/7/26.
 */
public class UserInfoDto extends UserInfo {
}
