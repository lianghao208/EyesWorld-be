package org.tvos.dto;

import org.tvos.entity.College;

/**
 * Created by Administrator on 2017/7/26.
 */
public class CollegeDto extends College {
}
